from flask import Flask, render_template, request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired
from werkzeug.utils import secure_filename
import os
app = Flask(__name__)
filenames = ['static/img/' + i for i in os.listdir(path="static/img")]
UPLOAD_FOLDER = 'static/img'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


class LoginForm(FlaskForm):
    idastro = StringField('Id астронавта', validators=[DataRequired()])
    astropass = PasswordField('Пароль астронавта', validators=[DataRequired()])
    idcapi = StringField('Id капитана', validators=[DataRequired()])
    capipass = PasswordField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


@app.route('/')
@app.route('/index')
def o():
    return render_template('base.html', title='Старт')


@app.route('/gallery', methods=['GET', 'POST'])
def new_gallery():
    global filenames
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            filename = os.path.join(app.config['UPLOAD_FOLDER'], filename).replace('\\', '/')
            filenames.append('/' + filename)
    return render_template('auto_answer.html', title='Красная планета', items=filenames)


@app.route('/table_param/<sex>/<age>')
def customize(sex, age):
    return render_template('auto_answer.html', sex=sex, age=int(age))


@app.route('/distribution')
def cauts():
    members = ['Ридли Скот', 'Энди Уир', 'Марк Уотни', 'Венката Капур', 'Тедди Сандерс', 'Шон Бин']
    return render_template('auto_answer.html', title='Каюты', user_list=members)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('auto_answer.html', title='Аварийный доступ', form=form)


@app.route('/training/<prof>')
def promotion(prof):
    if ('инженер' or "строитель") in prof:
        username = 'Инженерные тренажеры'
        image = '/static/img/ship1.jpg'
    else:
        username = 'Научные симуляторы'
        image = '/static/img/ship2.jpg'
    return render_template('index.html', username=username, cartinka=image)


@app.route('/list_prof/<numers>')
def spisok(numers):
    spi = ['инженер-исследователь', "пилот", "стритель", 'экзобиолог', 'врач', "инженер по терраформированию",
           "климатолог", 'специалист по радиационной защите', "астрогеолог", 'гляциолог', 'инженер жизнеобеспечения',
           'метеоролог', 'оператор марсохода', 'киберинженер', 'штурман', 'пилот дронов']
    if 'ol' == numers:
        for i in range(1, len(spi) + 1):
            spi[i - 1] = str(i) + '. ' + spi[i - 1]
        numers = 1
    else:
        for i in range(len(spi)):
            spi[i] = spi[i]
        numers = 0
    return render_template('auto_answer.html', spisok=spi, numers=numers)


@app.route('/answer')
def ans():
    rez = dict()
    rustrans = {'surname': 'Фамилия',
                'name': 'Имя',
                'education': 'Образование',
                'profession': 'Профессия',
                'sex': 'Пол',
                'motivation': 'Мотивация',
                'ready': 'Готовы остаться на Марсе?',
                'title': 'title'}
    rez['title'] = 'Анкета'
    rez['surname'] = 'Watny'
    rez['name'] = 'Mark'
    rez['education'] = 'выше среднего'
    rez['profession'] = 'штурман марсохода'
    rez['sex'] = 'male'
    rez['motivation'] = 'Всегда мечтал застрять на Марсе!'
    rez['ready'] = str(True)
    answers = []
    for i in rez:
        answers.append({'title': rustrans[i],
                        'content': rez[i]})
    results = {'results': answers}
    return render_template('auto_answer.html', news=results, title=rez['title'])


@app.route('/image_mars')
def image():
    return f"""<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <title>Привет, Марс!</title>
                  </head>
                  <body>
                    <h1>Жди нас, Марс!</h1>
                    <img src="{url_for('static', filename='img/ship.jpg')}" alt="здесь должна была быть картинка, 
    но не нашлась" height = 500>
    <p>Вот она какая, красная планета</p>
                  </body>
                </html>"""


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
